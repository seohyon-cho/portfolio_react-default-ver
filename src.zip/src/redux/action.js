// reducer에 요청을 보내는 함수가 있는 곳
